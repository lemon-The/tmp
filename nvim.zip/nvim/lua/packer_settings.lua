local ensure_packer = function()
    local install_path = vim.fn.stdpath('data')..'/site/pack/packer/start/packer.nvim'
    if vim.fn.empty(vim.fn.glob(install_path)) > 0 then
        vim.fn.system({'git', 'clone', '--depth', '1', 'https://github.com/wbthomason/packer.nvim', install_path})
        vim.cmd [[packadd packer.nvim]]
        return true
    end
    return false
end

local packer_bootstrap = ensure_packer()

return require('packer').startup(function(use)
    use 'wbthomason/packer.nvim'

	-- status line
    use {
        'nvim-lualine/lualine.nvim',
        requires = { 'kyazdani42/nvim-web-devicons', opt = true },
        config = function()
            require('plugins.lualine')
        end
    }
	
	-- lsp server downloader
	use {
		'williamboman/mason.nvim',
		config = function()
			require('plugins.mason_config')
			--require('mason-lspconfig').setup()
			--require('lspconfig').jdtls.setup ({})
		end
	}

	-- autocompletion plugins
	use {
		'neovim/nvim-lspconfig',
		config = function()
			require('plugins.lspconfig_conf')
		end
	}
	use 'hrsh7th/cmp-nvim-lsp' -- LSP source for nvim-cmp
	use 'hrsh7th/cmp-buffer'
	use 'hrsh7th/cmp-path'
	use 'hrsh7th/cmp-cmdline'
	use {
		'hrsh7th/nvim-cmp',
		config = function()
			require('plugins.cmp_conf')
		end
	}
	use ('L3MON4D3/LuaSnip')
	use ('saadparwaiz1/cmp_luasnip')

	-- use 'simrat39/rust-tools.nvim'
	-- use { 'simrat39/rust-tools.nvim',
	-- 	config = function()
	-- 		require('plugins.rust_tools')
	-- 	end
	-- }
	--use 'nvim-lua/plenary.nvim'
	--use 'mfussenegger/nvim-dap'

	-- fuzzy search
	use {
		'nvim-telescope/telescope.nvim', tag = '0.1.0',
		requires = { {'nvim-lua/plenary.nvim'} },
		config = function ()
			require('plugins.telescope_conf')
		end
	}

	-- themes
	use ('EdenEast/nightfox.nvim')
	use ('projekt0n/github-nvim-theme')
	use ('marko-cerovac/material.nvim')
	use ('rebelot/kanagawa.nvim')
	use ('ellisonleao/gruvbox.nvim')

	use ('Mofiqul/adwaita.nvim')
	use ('ray-x/aurora')
	use { "bluz71/vim-nightfly-colors", as = "nightfly" }
	use ('sainnhe/sonokai')

	use ('navarasu/onedark.nvim')
	use ({
		'nvim-treesitter/nvim-treesitter',
		run = function()
			require('nvim-treesitter.install').update({ with_sync = true })
		end,
        config = function()
			require('plugins.treesitter_conf')
		end
    })

    if packer_bootstrap then
        require('packer').sync()
    end
end)
