require('onedark').setup {
    style = 'warm'
}
require('onedark').load()
