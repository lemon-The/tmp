require('telescope').setup{
  --defaults = {
  --  layout_config = {
  --    	width = 0.9
  --    -- other layout configuration here
  --  }
  --},
  pickers = {
    find_files = {
      theme = "dropdown"
    },
	buffers = {
      theme = "dropdown"
	}
  }
--  extensions = {
--    -- ...
--  }
}
