-- TODO
-- further reading
    -- find out about local options for different filetypes
    -- vim.opt_local.formatoptions:append({ c = true, r = true, o = true, q = true })
    --! difference between vim.bo and vim.opt_local (:h lua-vim-options)
-- :h option-list
-- :h lua-vim-options
------------------------------------------------------------
-- print the line number in front of each line
vim.opt.number = true
-- enable the use of mouse clicks
vim.opt.mouse = 'a'
-- ignore case when completing file names
vim.opt.ignorecase = true
-- no ignore case when pattern has uppercase
vim.opt.smartcase = true
-- highlight matches with last search pattern
vim.opt.hlsearch = true
-- long lines wrap and continue on the next line
vim.opt.wrap = true
-- when and how to display the sign column
vim.opt.signcolumn = 'yes'
-- columns to highlight (right line)
vim.opt.colorcolumn = '75'

-- Russian layout for normal mode
vim.opt.keymap = 'russian-jcukenwin'
-- Input in english after start instead of russian
vim.opt.iminsert = 0
-- Search in english after start instead of russian
vim.opt.imsearch = 0

-- Spell checking in russian and english
-- vim.opt.spell = true
--vim.opt_local.spelllang = {'ru_ru', 'en_us'}
vim.opt_local.spelllang = {'ru_yo', 'en_us'}

-- colorsheme
-- vim.cmd("colorscheme nightfox")
-- vim.cmd("colorscheme kanagawa")
vim.cmd("colorscheme gruvbox")
-- vim.cmd("colorscheme sonokai")

--filetype = vim.filetype.match({buf = 0})
--print(filetype)

-- number of spaces that <Tab> in file uses
vim.opt.tabstop = 4
-- number of spaces to use for (auto)indent step (<<,>>)
vim.opt.shiftwidth = 4
-- use spaces when <Tab> is inserted
vim.opt.expandtab = false


require("luasnip.loaders.from_lua").load({paths = "~/.config/nvim/luaSnip/"})
require("luasnip").config.set_config({ -- Setting LuaSnip config

  -- Enable autotriggered snippets
  enable_autosnippets = false,

  -- Use Tab (or some other key if you prefer) to trigger visual selection
  store_selection_keys = "<Tab>",
})

-- autocmd
-- vim.api.nvim_create_autocmd({'BufEnter', 'BufWinEnter'}, {
--     pattern = {'*.css', '*.xml', '*.html'},
--     callback = function()
--         --vim.bo.tabstop = 2
--         vim.opt_local.tabstop = 2
--         vim.opt_local.shiftwidth = 2
--         vim.opt_local.expandtab = false
--     end
-- })
-- vim.api.nvim_create_autocmd({'BufEnter', 'BufWinEnter'}, {
--     pattern = {'*.tex'},
--     callback = function()
-- 		vim.opt.textwidth = 75
--     end
-- })
-- if filetype == 'java' then
--     vim.opt.tabstop = 1
--     vim.opt.shiftwidth = 1
--     vim.opt.expandtab = false
-- elseif filetype == nil then
--     vim.opt.tabstop = 4
--     vim.opt.shiftwidth = 4
--     vim.opt.expandtab = false
-- end
