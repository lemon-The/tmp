local ls = require("luasnip")
local s = ls.snippet
local sn = ls.snippet_node
local t = ls.text_node
local i = ls.insert_node
local f = ls.function_node
local d = ls.dynamic_node
local fmt = require("luasnip.extras.fmt").fmt
local fmta = require("luasnip.extras.fmt").fmta
local rep = require("luasnip.extras").rep

-- for dynamic node
local get_visual = function(args, parent)
  if (#parent.snippet.env.SELECT_RAW > 0) then
    return sn(nil, i(1, parent.snippet.env.SELECT_RAW))
  else  -- If SELECT_RAW is empty, return a blank insert node
    return sn(nil, i(1))
  end
end


return {
	-- Example: how to set snippet parameters
		s(
			{ -- Table 1: snippet parameters
				trig="start",
				dscr="Initiate new ConTeXt file",
				regTrig=false,
				priority=100,
				--snippetType="autosnippet"
			},
			-- Table 2: snippet nodes (don't worry about this for now---we'll cover nodes shortly)
			-- t("Hello, world!"), -- A single text node
			fmta(
				[[ \setupbodyfont[dejavu, 12pt]
	\mainlanguage[ru]
	\setuppapersize[A4]

	\setuppagenumbering[state=stop]

	\setuplayout[
	   top=2cm, 
	   header=0cm,
	   footer=0cm,
	   bottom=2cm]
	\setupinterlinespace[15pt]

	\define[2]\MySectionCommand%
	{\framed[frame=off,bottomframe=on,topframe=off]
	 {\vbox{#2}}}

	\define[2]\MySubSectionCommand%
	{\framed[frame=off,bottomframe=off,topframe=off]
	 {\vbox{#2}}}

	\definedescription[desc][alternative=left, width=2.6cm, headstyle=bold] 

	%\setuphead[section][command=\MySectionCommand, style={\tfb}]
	%\setuphead[subsection][command=\MySubSectionCommand, style={\bold}]
	\setuphead[section][style={\tfb}]
	\setuphead[subsection][style={\bold}]
	\setuphead[chapter][alternative=margin]

	\definehighlight[important][style=bold, color=red]

	\starttext
		<>
	\stoptext ]],
				{ i(1) }
			)
		  -- Table 3, the advanced snippet options, is left blank.
		),
		-- bold
		s(
			{ -- Table 1: snippet parameters
				trig="bl",
				dscr="Bold",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta(
				"\\bold{<>}",
				{ d(1, get_visual) }
			)
		),
		-- italic
		s(
			{ -- Table 1: snippet parameters
				trig="it",
				dscr="Italic",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta(
				"\\italic{<>}",
				{ d(1, get_visual) }
			)
		),
		-- important
		s(
			{ -- Table 1: snippet parameters
				trig="imp",
				dscr="Important",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta(
				"\\important{<>}",
				{ d(1, get_visual) }
			)
		),
		-- start chapter
		s(
			{ -- Table 1: snippet parameters
				trig="sch",
				dscr="Start chapter",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta(
				[[
	\startchapter[title={<>}, ownnumber={ }]
	\stopchapter
				]],
				{ d(1, get_visual) }
			)
		),
		-- start section
		s(
			{
				trig="sse",
				dscr="Start section",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta(
				[[
	\startsection[title={<>}]
	\stopsection
				]],
				{ d(1, get_visual) }
			)
		),
		-- start subsection
		s(
			{
				trig="sss",
				dscr="Start subsection",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta(
				[[
	\startsubsection[title={<>}]
	\stopsection
				]],
				{ d(1, get_visual) }
			)
		),
		-- start math
		s(
			{
				trig="math",
				dscr="Start math",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta("\\math{<>} ",
				{ d(1, get_visual) }
			)
		),
		-- enumeration (itemize)
		s(
			{
				trig="enum",
				dscr="Start enumeration",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta(
			[[
	\startitemize
		\item <>
	\stopitemize
			]],
				{ d(1, get_visual) }
			)
		),
		-- enumeration with arabic numbers (itemize)
		s(
			{
				trig="enuma",
				dscr="Start enumeration with arabic numbers",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta(
			[[
	\startitemize[n]
		\item <>
	\stopitemize
			]],
				{ d(1, get_visual) }
			)
		),
		-- enumeration with rom numbers (itemize)
		s(
			{
				trig="enumr",
				dscr="Start enumeration with arabic numbers",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta(
			[[
	\startitemize[R][stopper=]
		\item <>
	\stopitemize
			]],
				{ d(1, get_visual) }
			)
		),
		-- enumeration with letters (itemize)
		s(
			{
				trig="enuml",
				dscr="Start enumeration with arabic numbers",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta(
			[[
	\startitemize[a][right=), stopper=]
		\item <>
	\stopitemize
			]],
				{ d(1, get_visual) }
			)
		),
		-- start description
		s(
			{
				trig="description",
				dscr="Start description",
				regTrig=false,
				priority=100,
				snippetType="snippet"
			},
			fmta(
			[[
	\startdesc{<>}
	\stopdesc
			]],
				{ d(1, get_visual) }
			)
		),
}

