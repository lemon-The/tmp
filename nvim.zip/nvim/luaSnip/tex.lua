local ls = require("luasnip")
local s = ls.snippet
local sn = ls.snippet_node
local t = ls.text_node
local i = ls.insert_node
local f = ls.function_node
local d = ls.dynamic_node
local fmt = require("luasnip.extras.fmt").fmt
local fmta = require("luasnip.extras.fmt").fmta
local rep = require("luasnip.extras").rep


return {
	-- Example: how to set snippet parameters
	ls.snippet(
		{ -- Table 1: snippet parameters
			trig="start",
			dscr="Initiate new ConTeXt file",
			regTrig=false,
			priority=100,
			snippetType="autosnippet"
		},
		-- Table 2: snippet nodes (don't worry about this for now---we'll cover nodes shortly)
		-- t("Hello, world!"), -- A single text node
		fmta(
			[[ \\setupbodyfont[dejavu, 11pt]
			\\mainlanguage[ru]
			\\setuppapersize[A4]

			\\setuppagenumbering[state=stop]

			\\setuplayout[
			  top=2cm, 
			  header=0cm,
			  footer=0cm,
			  bottom=2cm]
			\\setupinterlinespace[15pt]
			\\starttext
			<>
			\\stoptext ]],
			{ i(1) }
		)
	  -- Table 3, the advanced snippet options, is left blank.
	),
}

