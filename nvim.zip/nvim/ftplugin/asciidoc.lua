-- Spell checking in russian and english
vim.opt.spell = true

vim.opt.textwidth = 74
