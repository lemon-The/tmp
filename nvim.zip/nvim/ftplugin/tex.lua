-- number of spaces that <Tab> in file uses
vim.opt_local.tabstop = 2
-- number of spaces to use for (auto)indent step (<<,>>)
vim.opt_local.shiftwidth = 2
-- use spaces when <Tab> is inserted
vim.opt_local.expandtab = false

-- Spell checking in russian and english
vim.opt.spell = true

vim.opt.textwidth = 74
